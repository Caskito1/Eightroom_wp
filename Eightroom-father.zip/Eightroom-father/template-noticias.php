<?php
/**
 * Template Name: Noticias Archive Template
 * 
 * Esta es la plantilla para mostrar el archivo de noticias.
 */

get_header(); ?>

<main id="main" class="main-container">
        
    <?php include('template-parts/banner-inicio-internas.php'); ?>
    <?php include('template-parts/content-novedades.php'); ?>
    <?php include('template-parts/banner-conocenos.php'); ?>
    
</main>
<?php get_footer(); ?>
