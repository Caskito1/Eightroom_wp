<?php
// Tipografías
function custom_theme_fonts() {
    wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap', array(), null );
    wp_enqueue_style( 'google-fonts-2', 'https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap', array(), null );
}
add_action( 'wp_enqueue_scripts', 'custom_theme_fonts' );

// Entrada Noticias
function custom_post_type() {
    register_post_type('noticias',
        array(
            'labels'      => array(
                'name'          => __('Noticias'),
                'singular_name' => __('Noticia'),
            ),
            'public'      => true,
            'has_archive' => true,
            'rewrite'     => array('slug' => 'noticias'),
            'supports'    => array('title', 'editor', 'thumbnail', 'custom-fields'),
            'taxonomies'  => array('category'),
        )
    );
}
add_action('init', 'custom_post_type');
add_theme_support('post-thumbnails');


//ACF
require_once get_template_directory() . '/inc/custom_fields/acf-single-noticias.php';

?>
 