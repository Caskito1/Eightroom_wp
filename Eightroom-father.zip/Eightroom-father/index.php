<?php get_header(); ?>

<div id="content" class="site-content">
    <div class="container">
        <div id="primary" class="content-area">
            <main id="main" class="site-main">
                <?php
                if ( have_posts() ) :
                    while ( have_posts() ) : the_post();
                        // Contenido del artículo
                        the_title( '<h1>', '</h1>' );
                        the_content();
                    endwhile;
                else :
                    // Mensaje para cuando no hay contenido disponible
                    echo '<p>No se encontró ningún contenido.</p>';
                endif;
                ?>
            </main>
        </div>
    </div>
</div>

<?php get_footer(); ?>