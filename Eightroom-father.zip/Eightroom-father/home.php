<?php
/*
 * Template Name: Home
 */
?>
 <?php include 'header.php'; ?>
 
  /* Contenido en Child */
<?php include 'footer.php'; ?>