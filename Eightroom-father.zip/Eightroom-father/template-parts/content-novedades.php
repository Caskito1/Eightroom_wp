<?php




$args = array(
    'post_type' => 'noticias', 
    'posts_per_page' => -1, 
);
$query = new WP_Query($args);


$stylesheet_url = get_template_directory_uri() . '/styles/css/content-novedades.css';
?>
<head>
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<?php if ($query->have_posts()) : ?>
<section class="section-card-container">
    <div class="grid-container">
        <?php while ($query->have_posts()) : $query->the_post(); ?>
            <div class="card">
              
            /* Contenido en tema Hijo */
         
        </div>
        <?php endwhile; ?>
</section>
<?php wp_reset_postdata(); ?>
<?php else : ?>
<p>No se encontraron noticias.</p>
<?php endif; ?>