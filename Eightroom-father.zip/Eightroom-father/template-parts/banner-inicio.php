<?php

?>
    <head>
        <link rel="stylesheet" href="<?php echo esc_url(get_stylesheet_directory_uri() . '/styles/css/banner-inicio.css'); ?>">
    </head>

    <body>
        <section class="general-container">
         /*Contenido en tema Hijo*/
        </section>
    </body>
 
