<?php
$args = array(
    'post_type' => 'noticias',
    'posts_per_page' => -1, 
);
$query = new WP_Query($args);


$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/banner-notas.css';

?>

<head>
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<?php if ($query->have_posts()) : ?>
<section class="section-card-container">

    /*Contenido en Tema Hijo*/
    
</section>
<?php wp_reset_postdata(); ?>
<?php else : ?>
<p>No se encontraron noticias.</p>
<?php endif; ?>

<script src="<?php echo get_stylesheet_directory_uri(); ?>../assets/js/banner-noticias.js"></script>