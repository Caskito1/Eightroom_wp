<?php
/*
 * Template Name: Home
 */
get_header(); ?>

<?php get_template_part( 'template-parts/banner-inicio', 'inicio' ); ?>
<?php get_template_part( 'template-parts/banner-noticias', 'noticias' ); ?>
<?php get_template_part( 'template-parts/banner-conocenos', 'conocenos' ); ?>

<?php get_footer(); ?>