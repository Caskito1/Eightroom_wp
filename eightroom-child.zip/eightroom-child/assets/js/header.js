
    document.addEventListener("DOMContentLoaded", function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const menuList = document.querySelector('.menu ul');
    const bars = document.querySelectorAll('.menu-toggle .bar');

    menuToggle.addEventListener('click', function() {
        menuList.classList.toggle('active');
        bars.forEach(bar => {
            bar.classList.toggle('active');
        });
    });
});

