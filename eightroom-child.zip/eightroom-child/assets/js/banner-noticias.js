
document.addEventListener('DOMContentLoaded', function() {
    const categorias = document.querySelectorAll('.categoria');
    const cards = document.querySelectorAll('.card');

    categorias.forEach(function(categoria) {
        categoria.addEventListener('click', function() {
            const catId = this.getAttribute('data-cat-id');
            if (catId === 'all') {
                for (let i = 0; i < cards.length; i++) {
                    if (i < 6) {
                        cards[i].style.display = 'block';
                    } else {
                        cards[i].style.display = 'none';
                    }
                }
            } else {
                cards.forEach(function(card) {
                    const cardCatIds = card.getAttribute('data-cat-ids').split(',');
                    if (cardCatIds.includes(catId)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }
            categorias.forEach(function(c) {
                c.classList.remove('active');
            });
            this.classList.add('active');
        });
    });

    // Mostrar solo las primeras 6 noticias al inicio
    for (let i = 0; i < cards.length; i++) {
        if (i >= 6) {
            cards[i].style.display = 'none';
        }
    }
});
