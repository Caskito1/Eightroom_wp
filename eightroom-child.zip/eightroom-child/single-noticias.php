<?php 
 
 $titulo_noticia = get_field('titulo_noticia');
 $subTitulo_noticia = get_field('subtitulo_noticias');
 $imagen_principal = get_field('imagen_principal');
 $parrafo_noticia = get_field('parrafo_noticia');
 $imagen_secundaria = get_field('imagen_secundaria');
 $parrafo_noticia2 = get_field('parrafo_noticia2');
 $foto = get_field('pie_foto_principal');
 $foto2 = get_field('pie_foto_secundaria');


 $categorias = get_the_category();


 function agregar_estilos() {

    wp_enqueue_style('estilo-principal', get_stylesheet_directory_uri() . '/style.css');
    wp_enqueue_style('estilo-header', get_stylesheet_directory_uri() . '/styles/css/single-noticias.css');
}

add_action('wp_enqueue_scripts', 'agregar_estilos');


 get_header(); ?>
<section class="menu-color"></section>
<section id="post-<?php the_ID(); ?>" class="section-noticias">
    <?php while (have_posts()) : the_post(); ?>

    <article class="container-noticias">
        <div class="title-container-noticias">
            <div class="categorias">
                <p>
                    <?php if ($categorias) {
                foreach ($categorias as $categoria) {
                    echo esc_html($categoria->name) ;
                }
            }
            ?>
                </p>
            </div>
            <h2><?php echo $titulo_noticia; ?></h2>
            <p> <?php echo $subTitulo_noticia; ?> </p>

        </div>

        <div class="separador"></div>

        <div class="imagen-principal">
            <img src=<?php echo $imagen_principal; ?> alt="Imagen principal">
            <p>Foto: <?php echo $foto; ?></p>
        </div>

        <div class="separador"></div>

        <div class="container-contenido-noticias">


            <p><?php echo $parrafo_noticia; ?></p>

            <?php if (!empty($imagen_secundaria)): ?>
            <div class="imagen-secundaria">
                <img src="<?php echo $imagen_secundaria; ?>" alt="Imagen secundaria">
                <p>Foto: <?php echo $foto2; ?> </p>
            </div>
            <?php endif; ?>
            <?php if (!empty($parrafo_noticia2)):?>
            <p><?php echo $parrafo_noticia2; ?></p>
            <?php endif; ?>
            <div class="separador"></div>
           
        </div>
    </article>

    <?php endwhile; ?>
</section>


<?php include('template-parts/banner-conocenos.php'); ?>

<?php get_footer(); ?>