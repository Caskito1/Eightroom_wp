<?php
$args = array(
    'post_type' => 'noticias',
    'posts_per_page' => -1, 
);
$query = new WP_Query($args);


$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/content-novedades.css';

?>

<head>
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<?php if ($query->have_posts()) : ?>
<section class="section-card-container">
    <div class="card-container">
        <div class="grid-container">
            <?php while ($query->have_posts()) : $query->the_post(); 
        $titulo_noticia = get_field('titulo_noticia');
        $subTitulo_noticia = get_field('subtitulo_noticias');?>
            <div class="card">
                <div class="conteiner-sup">
                    <div class="card-img">

                        <?php 
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('thumbnail');
                        }
                        ?>
                    </div>
                    <div class="categorias">
                        <p>
                            <?php 
                    
                        $categories = get_the_category();
                        
                        if ($categories) {
                            foreach ($categories as $categoria) {
                                echo esc_html($categoria->name);
                            }
                        }
                        ?>
                        </p>
                    </div>
                </div>

                <div class="card-text">

                    <h2><?php echo $titulo_noticia; ?></h2>
                    <p> <?php echo $subTitulo_noticia; ?> </p>

                    <a href="<?php the_permalink(); ?>">ver nota </a>


                </div>

            </div>
            <?php endwhile; ?>
        </div>
</section>
<?php wp_reset_postdata(); ?>
<?php else : ?>
<p>No se encontraron noticias.</p>
<?php endif; ?>