<?php

$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/banner-inicio-internas.css';
?>

<head>
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<body>

    <section class="general-container">
        <div class="data-container">
            <div class="info-container">
                <h2>Todas las noticias</h2>

            </div>
        </div>
        <div class="img-background"></div>
    </section>