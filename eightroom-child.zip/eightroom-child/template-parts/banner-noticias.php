<?php
$args = array(
    'post_type' => 'noticias',
    'posts_per_page' => -1, 
);
$query = new WP_Query($args);

$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/banner-noticias.css';
?>

<head>
    <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>

<?php if ($query->have_posts()) : ?>
<section class="section-card-container " id="noticias-destacadas">
    <div class="title-card-container">
        <h2><span>Noticias </span>Destacadas</h2>
    </div>
    <div class="solapas">
        <button class="categoria active" data-cat-id="all">Todos</button>
        <?php 
        $categories = get_categories();
        foreach ($categories as $category) {
            echo '<button class="categoria" data-cat-id="' . $category->term_id . '">' . $category->name . '</button>';
        }
        ?>
    </div>
    <div class="card-container">
        <div class="grid-container">
            <?php while ($query->have_posts()) : $query->the_post(); 
                $categories = get_the_category();
                $cat_ids = array();
                foreach ($categories as $cat) {
                    $cat_ids[] = $cat->term_id;
                }
                $titulo_noticia = get_field('titulo_noticia');
                $subTitulo_noticia = get_field('subtitulo_noticias');?>

            <div class="card" data-cat-ids="<?php echo implode(',', $cat_ids); ?>">
                <div class="conteiner-sup">
                    <div class="card-img">
                        <?php if (has_post_thumbnail()) {
                                the_post_thumbnail('thumbnail');
                            }
                            ?>
                    </div>
                    <div class="categorias">
                        <p>
                            <?php 
                                if ($categories) {
                                    foreach ($categories as $categoria) {
                                        echo esc_html($categoria->name);
                                    }
                                }
                                ?>
                        </p>
                    </div>
                </div>
                <div class="card-text">
                    <h2><?php echo $titulo_noticia; ?></h2>
                    <p> <?php echo $subTitulo_noticia; ?> </p>

                    <a href="<?php the_permalink(); ?>">ver nota </a>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    <div class="button-noticias">
        <?php
                     $url = esc_url(home_url()). '/'. 'novedades';
                    ?>
        <a href="<?php echo $url; ?>"><button>
                <p>Todas las noticias</p>
            </button></a>
    </div>

</section>
<?php wp_reset_postdata(); ?>
<?php else : ?>
<p>No se encontraron noticias.</p>
<?php endif; ?>
<script src="<?php echo get_stylesheet_directory_uri(); ?>../assets/js/banner-noticias.js"></script>