<?php

$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/banner-conocenos.css';
?>

<head>
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<body>

    <section class="general-container-knowus" id="sobre-nosotros">
        <div class="container-knowus">

            <div class="title-container-knowus">
                <h2>Soluciones de Marketing Digital para la <span>Industria del Juego.</span></h2>
            </div>

            <div class="text-info-container-knowus">
                <p>EightRoom ofrece servicios líderes en Marketing de Afiliación para el sector del juego en línea,
                    con más de 18 años de experiencia. Reconocidos con premios como el Mejor Afiliado Brasil BIS
                    2021 y el Mejor Afiliado Latam SAGGSE 2021, nuestro equipo de 80 expertos brinda estrategias
                    innovadoras y atención personalizada para impulsar la presencia digital de nuestros clientes a
                    nivel mundial. Contáctanos para descubrir cómo podemos llevar tu negocio al siguiente nivel.</p>
                <div class="cta-knowus">
                    <button>
                        <a target="_blank" href="https://eightroom.com/">
                            <p>Página Principal</p>
                        </a>
                    </button>
                </div>
            </div>


        </div>


    </section>