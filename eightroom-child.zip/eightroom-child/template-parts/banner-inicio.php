<?php
$stylesheet_url = get_stylesheet_directory_uri() . '/styles/css/banner-inicio.css';

?>


<head>
    <link rel="stylesheet" href="<?php echo esc_url($stylesheet_url); ?>">
</head>


<body>

    <section class="general-container">
        <div class="data-container">
            <div class="info-container">
                <h2><span>Actualízate </span>para Maximizar tus Oportunidades</h2>
                <p>Permanece al tanto de las últimas noticias deportivas. Mantente informado para tomar decisiones más
                    acertadas en tu estrategia de apuestas. Tu fuente confiable para potenciar tus posibilidades de
                    éxito.</p>

                <a href="#noticias-destacadas"><button>
                        <p>Noticias Destacadas</p>
                    </button></a>

            </div>
        </div>
        <div class="img-background"></div>
    </section>